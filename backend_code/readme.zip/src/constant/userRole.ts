export const ADMIN_ROLE = 'admin'
export const INSTRUCTOR_ROLE = `instructor`
export const STUDENT_ROLE = `student`