export const PAYMENT_FREE_STATUS = "free"
export const PAYMENT_PENDING_STATUS = "pending"
export const PAYMENT_PAID_STATUS = "paid"
export const PAYMENT_REFUND_STATUS = "refunded"