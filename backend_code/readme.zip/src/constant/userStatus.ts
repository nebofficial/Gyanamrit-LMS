export const ACTIVE_USER = `active`
export const PENDING_USER = `pending`
export const SUSPENDED_USER = `suspended`
export const VERIFIED_USER = 'verified'