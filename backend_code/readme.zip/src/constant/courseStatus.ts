export const DRAFT_COURSE = "draft"
export const PENDING_COURSE = "pending"
export const PUBSLISHED_COURSE = "published"
export const ARCHIVED_COURSE = "archived"


export const BASIC_LEVEL = "basic"
export const INTERMEDIATE_LEVEL = "intermediate"
export const ADVANCE_LEVEL="advanced"